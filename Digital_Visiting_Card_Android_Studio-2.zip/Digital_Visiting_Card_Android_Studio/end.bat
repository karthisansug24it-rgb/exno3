@echo off
title Finish Digital Visiting Card Session
cd /d "%~dp0"
echo This script safely stops Gradle background daemons if Gradle is available.
where gradle >nul 2>nul
if %errorlevel%==0 (
    gradle --stop
) else (
    echo Gradle command is not in PATH.
    echo You can close the project from Android Studio normally.
)
echo.
echo You can now close Android Studio when you are ready.
pause
