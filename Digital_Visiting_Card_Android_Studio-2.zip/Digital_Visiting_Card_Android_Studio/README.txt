DIGITAL VISITING CARD - ANDROID STUDIO PROJECT

Project title:
Digital Visiting Card

Language:
Java

Layout:
XML

HOW TO OPEN
1. Extract the ZIP file.
2. Open the extracted Digital_Visiting_Card_Android_Studio folder.
3. Double-click start.bat, or open Android Studio manually.
4. In Android Studio, choose Open and select this project folder.
5. Wait for Gradle Sync to complete.
6. Select an emulator or connect an Android phone with USB debugging enabled.
7. Press the Run button.

HOW TO FINISH
Run end.bat to stop Gradle daemons if the Gradle command is available.
Close Android Studio normally afterwards.

CUSTOMIZE
Edit app/src/main/res/layout/activity_main.xml to change the displayed name,
designation, phone number, email and address.

The profile picture is a simple vector avatar placeholder:
app/src/main/res/drawable/profile_avatar.xml
Replace it with your own image if required.

NOTE
Android Studio and an Android SDK are required. On first opening, Android Studio
may download the Gradle distribution and Android Gradle Plugin. Internet access
may be needed for the first Gradle Sync.
