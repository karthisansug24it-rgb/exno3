@echo off
title Open Digital Visiting Card
cd /d "%~dp0"
echo Opening Digital Visiting Card project...
where studio64.exe >nul 2>nul
if %errorlevel%==0 (
    start "" studio64.exe "%~dp0"
) else (
    where studio.exe >nul 2>nul
    if %errorlevel%==0 (
        start "" studio.exe "%~dp0"
    ) else (
        echo Android Studio launcher was not found in PATH.
        echo Open Android Studio, choose Open, and select this project folder:
        echo %~dp0
        start "" explorer.exe "%~dp0"
    )
)
echo.
echo Wait for Gradle Sync to finish in Android Studio.
pause
