package com.example.visitingcard;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/** Shows the digital visiting card. The card is display-only (no navigation). */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
