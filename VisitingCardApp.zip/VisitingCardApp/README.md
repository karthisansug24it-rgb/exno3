# Digital Visiting Card (MAD Lab)

Single-screen Android app that shows a freelance graphic designer's visiting card:
photo, name, designation, phone, email and address, in a bordered card-style design
(navy header, gold border, serif name). No buttons or navigation - just the card.

- Edit the details in `app/src/main/res/values/strings.xml`
- Replace the placeholder photo: delete `res/drawable/profile.xml`, add your image as `res/drawable/profile.jpg`

## Run
- Android Studio: File > Open this folder, wait for sync, press Run
- Windows: start an emulator/phone, then double-click `run_app.bat`

Requires JDK 17 (bundled with Android Studio) and Android SDK 34.
